﻿using System;
using System.Collections.Generic;
using System.Linq;
using DefiningClasses;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Person person1 = new Person();
            Person person2 = new Person("Peter", 18);
            person1.Name = "Ivan";
            person1.Age = 30;
        }
    }
}