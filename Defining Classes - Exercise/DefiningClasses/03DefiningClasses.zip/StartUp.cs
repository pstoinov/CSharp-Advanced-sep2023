﻿using System;
using System.Collections.Generic;
using System.Linq;
using DefiningClasses;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            Family familyMembers = new();

            for (int i = 0; i < n; i++) 
            {
                string[] input = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
                familyMembers.addFamilyMember(input[0], int.Parse(input[1]));
            }
            Person oldestMember = familyMembers.getOldestFamilyMember(familyMembers.FamilyMember);
            Console.WriteLine($"{oldestMember.Name} {oldestMember.Age}");
        }
    }
}