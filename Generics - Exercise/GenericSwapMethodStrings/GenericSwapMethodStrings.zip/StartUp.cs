﻿
namespace GenericSwapMethodStrings;
public class StartUp
{
    public static void Main(string[] args)
    {
        int n = int.Parse(Console.ReadLine());

        Box<string> list = new Box<string>();

        for (int i = 0; i < n; i++)
        {
            string input = Console.ReadLine();
            list.Add(input);
        }

        int[] indexes = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToArray();

        list.Swap(indexes[0], indexes[1]);

        Console.WriteLine(list.ToString());

        //foreach (var item in list) 
        //{
        //    Console.WriteLine($"{typeof(string)}: {item}");
        //}


        //static void Swap<T>(int firstIndex, int secondIndex, List<T> list)
        //{
        //    T swap = list[firstIndex];
        //    list[firstIndex] = list[secondIndex];
        //    list[secondIndex] = swap;
        //}
    }
}